---
title: Primera reunión con el profesor de prácticas
date: 01/10/2021
---

# Primera reunión

- Mucha comunicación
- User for all, no centrarnos solo en discapacidad visual
    - Alternate text para imagenes
    - Cuidado con la pantalla tactil
- Modo tactil normal y ademas modo discapacidad visual
- Marcadores físicos para mostrar zonas destacadas
    - NTF + Relieve en una columna
    - Lo del GPS + Orientación igual es demasiado impreciso
- Diseñar la aplicación para que sea usable por sistemas tipo lectores de pantalla para personas invidentes
- Simular la base de datos para las clases
    - Notificar el acceso del profesor
    - No simplificar demasiado el tema de las plantas con el GPS
    - Nos va a pasar el mapa de la facultad GPS
    - Le parece bastante bien el tema de navegación
- Perfil de usuario
    - Datos personales del usuario
    - Poder manejar tareas / entregas / deadlines
    - Poner tareas personales del usuario o deadlines personales, como si fuese un calendario
    - No tiene mucho que ver con NPI, asi que dejarlo para el final
    - Se pueden hacer las notas / tareas por notas de voz
    - Es importante integrar nuevos paradigmas en la aplicación
    - **Reusar las cosas** que esten hechas, porque el integrar notas de voz lo hace ya android por defecto con el teclado. Es importante dar valor añadido a las cosas que hagamos
    - Le da bastante importancia al marketing del producto que vayamos a desarrollar, al *"valor añadido"*
