# AgilUGR

- Aplicación para mejorar tu productividad durante la estancia en la Universidad de Granada

# Generación de la documentación

- Correr `gradle dokkaHtml`
- También se puede usar `./gradlew` en vez de `gradle`
- La documentación se encuentra en `app/documentation/html`
    - Abir con `firefox app/documentation/html/index.html`
