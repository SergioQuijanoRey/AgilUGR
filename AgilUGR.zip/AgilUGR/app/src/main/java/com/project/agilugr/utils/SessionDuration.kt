package com.project.agilugr.utils

/** Clase que representa la duracion de una sesion de focus*/
data class SessionDuration(val hours: Int, val minutes: Int, val seconds: Int)