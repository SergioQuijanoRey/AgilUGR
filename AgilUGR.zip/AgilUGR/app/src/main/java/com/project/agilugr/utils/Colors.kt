/**
 * Fichero en el que guardamos los colores que vamos a usar en toda la app
 * */
package com.project.agilugr.utils

const val lightGrey = 0xa0bdbdbd
const val primaryAccent = 0xFF4db6ac
// layout
const val headerBackground = 0xFF5186B0 // blanco roto
const val MainBackground =  0xFFE4F4FB // azul grisaceo
const val events = 0xFFA3BFD5 // blanco
const val stopevent=0xFFF796A2
// icons
const val iconColor = 0xA9A9A9
